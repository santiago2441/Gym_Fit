-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: gim_fit
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `gim_fit`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `gim_fit` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `gim_fit`;

--
-- Table structure for table `compra`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `compra` (
  `id_comp` int(20) NOT NULL,
  `prod` text NOT NULL,
  PRIMARY KEY (`id_comp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--


--
-- Table structure for table `contra_before`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `contra_before` (
  `documento` int(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fecha_actualizacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contra_before`
--

INSERT INTO `contra_before` (`documento`, `password`, `fecha_actualizacion`) VALUES (1192907232,'$2y$12$FD.TB42J.pq.Ko6xR0m5lOFkA4r8Sj/4MXSbDS6ZKgcmuF.FPcvMC','2023-07-17'),(1192907232,'$2y$12$/RJAnMj4bVX6/mpVRAeRDubpubPBXMkOdR2bBx0HcrwgwdbF498Ei','2023-07-17'),(1192907232,'$2y$12$OyzRTW68V1RFbj8E4nedgOdgK/9UBd6i3Yh9UeU2suHs/4A.5gDiS','2023-07-17'),(1192876232,'','2023-07-24'),(1192876232,'','2023-07-24'),(1192907232,'$2y$12$FD.TB42J.pq.Ko6xR0m5lOFkA4r8Sj/4MXSbDS6ZKgcmuF.FPcvMC','2023-07-17'),(1192907232,'$2y$12$/RJAnMj4bVX6/mpVRAeRDubpubPBXMkOdR2bBx0HcrwgwdbF498Ei','2023-07-17'),(1192907232,'$2y$12$OyzRTW68V1RFbj8E4nedgOdgK/9UBd6i3Yh9UeU2suHs/4A.5gDiS','2023-07-17'),(1192876232,'','2023-07-24'),(1192876232,'','2023-07-24');

--
-- Table structure for table `datos_fisicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `datos_fisicos` (
  `id_datos` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_registro` date NOT NULL,
  `documento` int(10) NOT NULL,
  `peso` float NOT NULL,
  `grasa` tinytext NOT NULL,
  `nivel_mus` tinytext NOT NULL,
  `talla_hueso` text NOT NULL,
  `metabol` text NOT NULL,
  `proteina` tinytext NOT NULL,
  `obesidad` tinytext NOT NULL,
  `pecho` float NOT NULL,
  `cintura` float NOT NULL,
  `brazo` float NOT NULL,
  `espalda` float NOT NULL,
  `cadera` float NOT NULL,
  `pierna` float NOT NULL,
  `gemelos` float NOT NULL,
  `BMI` float NOT NULL,
  PRIMARY KEY (`id_datos`),
  KEY `documento` (`documento`),
  CONSTRAINT `datos_fisicos_ibfk_1` FOREIGN KEY (`documento`) REFERENCES `usuario` (`documento`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datos_fisicos`
--


--
-- Table structure for table `detalle_venta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `detalle_venta` (
  `id_deta_ven` int(11) NOT NULL AUTO_INCREMENT,
  `id_venta` int(30) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`id_deta_ven`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `detalle_venta_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `venta` (`id_venta`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_venta`
--


--
-- Table structure for table `estado`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `estado` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `estado` text NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado`
--

INSERT INTO `estado` (`id_estado`, `estado`) VALUES (1,'Activo'),(2,'Inactivo');

--
-- Table structure for table `genero`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `genero` (
  `id_genero` int(11) NOT NULL AUTO_INCREMENT,
  `genero` tinytext NOT NULL,
  PRIMARY KEY (`id_genero`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genero`
--

INSERT INTO `genero` (`id_genero`, `genero`) VALUES (1,'Masculino'),(2,'Femenino');

--
-- Table structure for table `inventario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `inventario` (
  `id_inven` int(20) NOT NULL,
  `id_prod` int(20) NOT NULL,
  `id_comp` int(20) NOT NULL,
  PRIMARY KEY (`id_inven`),
  KEY `id_prod` (`id_prod`),
  KEY `id_comp` (`id_comp`),
  CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`id_prod`) REFERENCES `producto` (`id_prod`) ON UPDATE CASCADE,
  CONSTRAINT `inventario_ibfk_2` FOREIGN KEY (`id_comp`) REFERENCES `compra` (`id_comp`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--


--
-- Table structure for table `precio_suscripcion`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `precio_suscripcion` (
  `id_valor` int(11) NOT NULL AUTO_INCREMENT,
  `valor` decimal(10,3) NOT NULL,
  PRIMARY KEY (`id_valor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `precio_suscripcion`
--

INSERT INTO `precio_suscripcion` (`id_valor`, `valor`) VALUES (1,20.000);

--
-- Table structure for table `producto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `producto` (
  `id_prod` int(20) NOT NULL,
  `comprador` int(10) NOT NULL,
  `prod` text NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `descrip` text NOT NULL,
  `cant` int(10) NOT NULL,
  PRIMARY KEY (`id_prod`),
  KEY `comprador` (`comprador`),
  CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`comprador`) REFERENCES `usuario` (`documento`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--


--
-- Table structure for table `rol`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rol` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `rol` tinytext NOT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

INSERT INTO `rol` (`id_rol`, `rol`) VALUES (1,'Administrador'),(2,'Coach'),(3,'usuario');

--
-- Table structure for table `suscripcion`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `suscripcion` (
  `id_susc` int(11) NOT NULL AUTO_INCREMENT,
  `docu_adco` int(10) NOT NULL,
  `docu_usuario` int(10) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `valor` int(11) NOT NULL,
  PRIMARY KEY (`id_susc`),
  KEY `documento` (`docu_usuario`),
  KEY `id_valor` (`valor`),
  CONSTRAINT `suscripcion_ibfk_1` FOREIGN KEY (`docu_usuario`) REFERENCES `usuario` (`documento`) ON UPDATE CASCADE,
  CONSTRAINT `suscripcion_ibfk_2` FOREIGN KEY (`valor`) REFERENCES `precio_suscripcion` (`id_valor`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suscripcion`
--


--
-- Table structure for table `tabla_ingreso`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `tabla_ingreso` (
  `id_ingreso` int(11) NOT NULL AUTO_INCREMENT,
  `documento` int(11) NOT NULL,
  `fecha_ingreso` datetime NOT NULL,
  `fecha_salida` datetime NOT NULL,
  PRIMARY KEY (`id_ingreso`),
  KEY `documento` (`documento`),
  CONSTRAINT `tabla_ingreso_ibfk_1` FOREIGN KEY (`documento`) REFERENCES `usuario` (`documento`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabla_ingreso`
--

INSERT INTO `tabla_ingreso` (`id_ingreso`, `documento`, `fecha_ingreso`, `fecha_salida`) VALUES (13,1192907232,'2023-08-14 17:09:22','2023-08-14 17:09:23'),(14,1192907232,'2023-08-14 17:22:57','2023-08-14 17:22:58'),(15,1192907232,'2023-08-14 17:23:59','2023-08-14 17:24:01'),(16,1192907232,'2023-08-14 10:27:16','2023-08-14 10:27:19'),(17,1192907232,'2023-08-16 10:52:28','2023-08-14 10:53:05'),(18,1192907232,'2023-08-14 11:08:14','2023-08-14 11:31:14'),(19,1192907232,'2023-08-14 11:31:31','2023-08-14 11:32:07'),(20,1192907232,'2023-08-14 11:32:30','2023-08-14 11:32:53'),(21,1192907232,'2023-08-14 11:34:01','2023-08-18 05:35:57'),(22,1192907232,'2023-08-18 05:33:50','2023-08-18 05:35:57');

--
-- Table structure for table `tp_servicio`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `tp_servicio` (
  `id_servicio` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_servicio` text NOT NULL,
  `costo_servicio` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id_servicio`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tp_servicio`
--


--
-- Table structure for table `usuario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `usuario` (
  `documento` int(10) NOT NULL,
  `nombres` tinytext NOT NULL,
  `apellidos` tinytext NOT NULL,
  `edad` int(3) NOT NULL,
  `peso` int(11) NOT NULL,
  `estatura` varchar(4) NOT NULL,
  `fecha_naci` date NOT NULL,
  `telefono` float NOT NULL,
  `correo` text NOT NULL,
  `password` varchar(100) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `id_genero` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  PRIMARY KEY (`documento`),
  KEY `id_estado` (`id_estado`),
  KEY `usuario_ibfk_2` (`id_rol`),
  KEY `id_genero` (`id_genero`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_estado`) REFERENCES `estado` (`id_estado`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `usuario_ibfk_2` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`documento`, `nombres`, `apellidos`, `edad`, `peso`, `estatura`, `fecha_naci`, `telefono`, `correo`, `password`, `id_rol`, `id_genero`, `id_estado`) VALUES (1192907232,'Jaime','Orduz',21,0,'1.81','2001-08-10',3102270000,'jailorduz@misena.edu.co','$2y$12$rroLFRqpKkbxXw6c7/zI1usn0UNRDUb65P/30Hdrms0pwDEIbz/d2',1,1,1),(1234567899,'kevin','jaims',0,0,'','0000-00-00',123457000,'kajaimes@gmail.com','$2y$12$F1tQhYkQJgayXooRDEfYrus1v/o8sSSfuxagy8/CeD28TAFvXvSJq',2,1,2);
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `Trigger_contraseñas` BEFORE UPDATE ON `usuario` FOR EACH ROW INSERT INTO contra_before (documento,password,fecha_actualizacion) VALUES (old.documento, old.password,Now()) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `vender_servicio`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `vender_servicio` (
  `id_venta_ser` int(11) NOT NULL AUTO_INCREMENT,
  `coach` int(10) NOT NULL,
  `usuario` int(10) NOT NULL,
  `servicio` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id_venta_ser`),
  KEY `usuario` (`usuario`),
  KEY `servicio` (`servicio`),
  CONSTRAINT `vender_servicio_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `usuario` (`documento`) ON UPDATE CASCADE,
  CONSTRAINT `vender_servicio_ibfk_2` FOREIGN KEY (`servicio`) REFERENCES `tp_servicio` (`id_servicio`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vender_servicio`
--


--
-- Table structure for table `venta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `venta` (
  `id_venta` int(20) NOT NULL,
  `docu_coach` int(10) NOT NULL,
  `docu_usuario` int(10) NOT NULL,
  `fecha_venta` date NOT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `docu_usuario` (`docu_usuario`),
  CONSTRAINT `venta_ibfk_2` FOREIGN KEY (`docu_usuario`) REFERENCES `usuario` (`documento`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--


--
-- Dumping routines for database 'gim_fit'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-23  7:37:09
